# quiz4.py

menu = [
        "Hotdog",
        "Adobong Manok",
        "Spaghetti",
 ]

prices = [
    30,
    60,
    25,
]


template = "What do you like to order? "
output = template.format(menu)
menu1 = menu[0:1]
menu2 = menu[1:2]
menu3 = menu[2:3]

menu1.append(prices[0:1])
menu2.append(prices[1:2])
menu3.append(prices[2:3])


print (output)

print ("(1)" + str(menu1))
print ("(2)" + str(menu2))
print ("(3)" + str(menu3))
order = input("What do you like to order?")
print (order)

if int(order) == 1:
    print(menu1)
elif int(order) == 2:
    print(menu2)
else :
    print(menu3) 

money = input("How much is your money? ")
if money >= prices:
    print

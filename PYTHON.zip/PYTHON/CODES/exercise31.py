# exercise31.py
# data type:

def greet_morning():
    print("Good morning")
    
def greet_afternoon():
    print("Good afternoon")

def greet_evening():
    print("Good evening")
    
def greet_default():
    print("Hello")

choice = input("Choose 1, 2, or 3: ")
#if choice == "1":
#    greet = greet_morning
#elif choice == "2":
#    greet = greet_afternoon
#elif choice == "3":
#    greet = greet_evening
#else:
#    greet = greet_default

funcs = {
        "1": greet_morning,
        "2": greet_afternoon,
        "3": greet_evening,
}
greet = funcs.get(choice, greet_default)
greet()

print(greet)
print(type(greet))
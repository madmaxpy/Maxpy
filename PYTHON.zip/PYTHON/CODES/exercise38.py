# exercise38.py
#lambda/anonymous function

menu =[
    "Chicken",
    "burger",
    "rice",
    "Beans",
]


menu.sort(key=lambda x: x.lower())
print(menu)
"""
exercise28.py
 Demonstrates functions, dunder, and docstring
"""

def greet_morning(name, emotion="happy"):
    "Function to greet good morning"
    print("Good morning " + name)
    print("You are " + emotion)

def add(a,b):
    """
    Function to add two variables.
    Returns the result
    """
    return a+b

# dunder = double underscore
if __name__ == "__main__":
    
    greet_morning("Alyssa")
    greet_morning("Alyssa", "excited")
    greet_morning(name="Alyssa", emotion="excited")
    greet_morning(emotion="excited", name="Alyssa")

    result = add(1, 1)
    print(result)
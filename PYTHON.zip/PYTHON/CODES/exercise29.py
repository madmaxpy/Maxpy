# exercise29.py
import exercise28
from exercise28 import greet_morning

exercise28.greet_morning("Alyssa", "confused")
greet_morning("Alyssa")

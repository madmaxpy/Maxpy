#answerquiz8.py

names = [
        "Hotdog",
        "Adobong Manok",
        "Spaghetti",
 ]

prices = [
    30,
    60,
    25,
]

menu = {}

for i, row in enumerate (zip(names, price)):
    menu
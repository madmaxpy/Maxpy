#exercise26.py

names = ["Betty", "Veronica", "Alice", "Bob"]
names.sort()

names.reverse()


print (names)

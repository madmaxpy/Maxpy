# quiz4.py

menu = [
        "Hotdog",
        "Adobong Manok",
        "Spaghetti",
 ]

prices = [
    30,
    60,
    25,
]
template ="{}: {} {}"
for i in [0, 1, 2]:
    print(template.format(i + 1, menu[i], prices [i]))

choice = input("What do you want? ")
choice = int(choice) - 1

template ="{}..........{}"
print("====")
print("")
print (template.format(menu[choice], prices[choices]))
print("====")
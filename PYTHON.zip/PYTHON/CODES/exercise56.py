#exercise56.py

from flask import Flask, url_for, redirect, request

app = Flask(__name__)

@app.route("/")
def show_login():
    html = """
<form action="{}" method="post">
    Username: <input type="text" name="user" /> <br>
    Password: <input type="password" name="password" /> <br>
    <input type ="submit"/>
</form>
"""
    html = html.format(url_for("check_password"))
    return html

@app.route("/success")
def show_success():
    return "success"

@app.route("/fail")
def show_fail():
    return "fail"

@app.route("/login", methods=["POST"])
def check_password():
    if (request.form["user"] == "admin" and
        request.form["password"] == "1234"):
        return redirect(url_for("show_success"))
    else:
        return redirect(url_for("show_fail"))



if __name__ == "__main__":
    app.run(debug=True) #, port=80, host="0.0.0.0")
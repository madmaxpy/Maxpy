# exercise36.py
#lambda/anonymous function

menu =[
    ["Chicken", 35],
    ["Burger", 30],
    ["Rice", 10],
    ["Beans", 30],
]

#def get_price(element):
#   print(element)
#    return element [1]

#menu.sort(key=get_price)

#menu.sort(key=lambda element: element[1])
menu.sort(key=lambda x: x[1])
print(menu)
#Make a dice game
#Ask the user for a dice. Each die should be its own function
# 6-sided die
#12-sided die
#Ask the user for a number
#Roll the dice. If the dice result is divisible by the number, the user wins

choice = ["6 sided", "12 sided",]
template = "What do you like? "
output = template.format(choice)
    print(output)
import random

dice =["6",
		"12",
		]

best = random.choice(dice)
power = random.randint(0, 7)

template = "The dice {}. The number is {}"
output = template.format(best, power)
print(output)
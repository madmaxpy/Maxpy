#exercise42.py
# python debugger

#commands
#l  - list
#n - next
# p - print
# pp - pretty print
# c - continue
# l # - display that line #
# q - quit
# s - step


def add(a,b):
    total = a + b
    return total

#import pdb;pdb.set_trace()
breakpoint()
a = 1
b = 1
c = add(a,b)

print(c)
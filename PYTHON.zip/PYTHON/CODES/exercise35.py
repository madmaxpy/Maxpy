# exercise35.py

import turtle
turtle.forward(200)
turtle.left(90)
turtle.penup()
turtle.forward(200)
turtle.left(90)
turtle.pendown()
turtle.forward(200)
turtle.left(90)
turtle.forward(200)


turtle.exitonclick()
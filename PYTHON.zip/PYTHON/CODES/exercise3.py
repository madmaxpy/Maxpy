# exercise3.py
print ("How old are you? ")

age = input()
age = int(age) + 10

#print("In ten years, you will be " + str(age) + " years old")
#print("In ten years, you will be {} years old".format(age))

template = "In ten years, you will be {} years old"
output = template.format(age)
print(output)

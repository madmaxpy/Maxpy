#exercise45.py
import requests

data = {
	"name": "test",
	"id": 1,
}

r = requests.post("https://httpbin.org/post", data=data)

print(r)
print(r.url)
print(r.text)
#exercise45.py
import requests

data = {
	"name": "test",
	"id": 1,
}

jar = requests.cookies.RequestsCookieJar()
jar.set("password", "1234",
        domain="httpbin.org", path="/cookies")

r = requests.get("https://httpbin.org/cookies",
                cookies=jar)

print(r.text)
print(r.cookies)
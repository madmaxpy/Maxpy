#exxercise18.py
#data type: multi-line string
#\n - newline
#\' -'
#\"-"
#\\-\
#prefix strings with r, it will not translate special characters-

sentence = """The quick 'brown' fox
jumps over 
the lazy dog"""

print('The \'quick\'fox')
print('c:\\windows\\temp')
print(r'c:\windows\temp \n c:\windows\ ')

print(sentence)
print(sentence.count("\n") +1)
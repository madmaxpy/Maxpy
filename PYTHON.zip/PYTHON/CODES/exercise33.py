# exercise33.py
# error handling

#empty code block
#void foo()
#{
#}

class NotBeautifulEnough(Exception):
    pass

try:
    raise NotBeautifulEnough("That's me")
    print(password)
    int("Eleven")
    1 / 0
except ZeroDivisionError:
    print("Bawal ang pag-divide sa zero")
except (ValueError, NameError):
    print("Not a valid input")
except: #not recommended
    print("may error")
#raise

try:
    #raise SyntaxError
    print("Hello world")
except:
    print("Ther's error")
finally:
    print("Always do this")

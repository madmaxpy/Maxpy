#exercise26.py

names = ["Betty", "Veronica", "Alice", "Bob"]

names2 = sorted(names)
names2 =  list(reversed(names2))
print (names)
print (names2)

for name in sorted(names):
    print(name)
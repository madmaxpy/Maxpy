# exercise15.py
# enumerate() function

names = ["Hotdog", "Adobong Manok", "Spaghetti", "Rice"]

for i, name in enumerate (names):
    print(i, name)
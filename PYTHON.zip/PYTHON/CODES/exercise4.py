# exercise4.py
sentence = "The quick brown fox jumps over the lazy dog"

print(sentence.upper())
print(sentence.lower())
print(sentence.swapcase())
print(sentence.title())
print(sentence.replace("FOX".lower(), "cat"))
print(sentence.replace("h", ""))
print(sentence.replace("jumps", "talk"))

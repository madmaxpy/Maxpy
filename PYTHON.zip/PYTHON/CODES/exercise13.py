# exercise11.py
# zip() function

names = ["Hotdog", "Adobong Manok", "Spaghetti","Rice"]
prices = [30, 60, 25,]
stocks = [10, 2, 0, 200]

template = "We have {} {}. They cost {} each"

for name, price, stock in zip(names, prices, stocks):
    print(template.format(stock,name,price))
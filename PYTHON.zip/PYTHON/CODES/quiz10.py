#quiz10.py
# make a website that contains 3 jokes


from flask import Flask, url_for

app = Flask(__name__)

@app.route("/")

def index():
    template = """
<a href="{}"><b>Joke 1</b></a>
<a href="{}"><b>Joke 2</b></a>
<a href="{}"><b>Joke 3</b></a>

"""
    output = template.format(url_for("greet_joke1"),
                             url_for("greet_joke2"),
                             url_for("greet_joke3"))
    return output

@app.route("/joke1")
def greet_joke1():
    html = """<img src="{}" />"""
    html = html.format(url_for("static", filename="kittens2.jpg"))
    return "<center> "  + html + "<br/>" + "<h1>Ano ang tawag sa grupo ng pusa? Edi PangCAT </h1>" + "</center>"
    
@app.route("/joke2")
def greet_joke2():
    html = """<img src="{}" />"""
    html = html.format(url_for("static", filename="unano.jpg"))
    return "<center> "  + html + "<br/>" + "<h1>Ano ang tawag sa maliit na unan? Edi UNANo </h1>" + "</center>"
    
@app.route("/joke3")
def greet_joke3():
    html = """<img src="{}" />"""
    html = html.format(url_for("static", filename="chickenjoy.jpg"))
    return "<center> "  + html + "<br/>" + "<h1>Anong manok ang masaya pag kinatay? Edi Chickenjoy </h1>" + "</center>"

if __name__ == "__main__":
    app.run(debug=True) #, port=80, host="0.0.0.0")
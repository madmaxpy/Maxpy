#exercise23.py

f= open("Hello.txt", "r")
data = f.read()
f.close()

print(data)
print(type(data))
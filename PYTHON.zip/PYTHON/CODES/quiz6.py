# quiz5.py
# Make a POS program
# Show the user the menu. Use unpacking, zip, enumerate, or range
# Ask the user what they want to order until they want to stop
# print a receipt

names = [
        "Hotdog",
        "Adobong Manok",
        "Spaghetti",
 ]

prices = [
    30,
    60,
    25,
]
template ="{}: {} {}"
for i in range(len(names)):
    print(template.format(i + 1, names [i], prices [i]))

cart = []

choice = input("Do you still want to order y/n?")
choice = int(choice) - 1

template ="{}..........{}"
print("====")



while True:
    print (" Unionbank restaurant ")
    choice = input("Do you still want to order y/n?")
    if choice.lower() in ["n", "no", "hinde", "ayaw na"]:
         break
    else:
        cart.append(choice)
        continue
    print("Again")
    print (template.format(names[choice], prices[choice]))
    
template ="{}: {} {}"
print("====")
print(" Unionbank Restaurant ")
print ("")
for choice in cart:
    print (template.format(names[choice], prices[choice]))
print("=====")
#exercise45.py
import requests

data = {
	"name": "test",
	"id": 1,
}
headers = {"user-agent": "adorable/1.0"}

r = requests.get("https://httpbin.org/get", 
                params=data,
                headers=headers)


print(r.url)
print(r.text)
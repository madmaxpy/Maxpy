# exercise16.py
# while loop
# while <condition>:

while True:
    print("I am sexy")
    
    reply = input("Are you still sexy (y/n)? ")
    if reply.lower() in ["n", "no", "hinde", "ayaw na"]:
        break
    else:
        continue
    print("Again")
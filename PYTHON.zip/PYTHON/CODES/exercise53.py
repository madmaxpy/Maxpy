#exercise53.py

from flask import Flask, url_for

app = Flask(__name__)

@app.route("/")
def index():
    template = """
<a href="{}">Morning</a>
<a href="{}">Afternoon</a>

"""
    output = template.format(url_for("greet_morning"),
                             url_for("greet_afternoon"))
    return output

@app.route("/morning")
def greet_morning():
    return "Good morning"
    
@app.route("/afternoon")
def greet_afternoon():
    return "Good afternoon"
    
if __name__ == "__main__":
    app.run(debug=True) #, port=80, host="0.0.0.0"
#exercise57.py

from flask import Flask, request, render_template

app = Flask(__name__)

#http://localhost:5000
#http://localhost:5000/?q=cats
@app.route("/")
def index():
    search_query = request.args.get("q")
    fruits = ["Apple", "Banana"]
    return render_template("Hello.html", search_query=search_query, fruits=fruits)



if __name__ == "__main__":
    app.run(debug=True) #, port=80, host="0.0.0.0")
#exercise48.py

class Animal:
    def __init__(self):   #constructor
        print("Animal created")
        
    def speak(self):
        print("Animal speaks")
        
class Dog(Animal):
    def speak(self):
        print("arf arf")

class Dalmatian(Dog):
    def __init__(self, name):
        self.name = name
    def speak(self):
        print("{} says".format(self.name))
        super().speak()

class Fox(Dog):
    def speak(self):
        print("wreeeee")
        
animal1 = Animal()
animal2 = Animal()
animal3 = Dog()
animal4 = Dalmatian("Bantay")
animal5 = Dalmatian("Chin")

#animal.speak()
#animal2.speak()
#animal3.speak()
#animal4.speak()
#animal5.speak()

zoo = [animal1, animal2, animal3, animal4, animal5]
zoo.append(Fox())
for animal in zoo:
    animal.speak()
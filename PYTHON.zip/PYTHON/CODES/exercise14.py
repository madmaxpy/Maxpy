# exercise14.py
# range() function

# for i in range(10):
# for i in range(5, 10):
for i in range(5, 10, 2):
    print(i)
    
print ("====")
names= ["Hotdog", "Adobong Manok", "Spaghetti", "Rice"]

for i in range(len(names)):
    print(i)
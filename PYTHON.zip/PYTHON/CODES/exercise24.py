#exercise24.py
# r - read

f = open("Hello.txt", "r")

for line in f:
    #print(line, end="")
    print(line.strip())

f.close()

with open ("Hello.txt","r") as f:
    for line in f:
    #print(line, end="")
    print(line.strip())
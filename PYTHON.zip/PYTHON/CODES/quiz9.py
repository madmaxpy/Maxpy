import turtle

turtle.forward(200)
turtle.left(90)
turtle.pendown()
turtle.forward(200)
turtle.right(90)
turtle.forward(140)
turtle.right(90)
turtle.pendown()
turtle.forward(90)
turtle.right(90)
turtle.forward(140)
turtle.right(220)
turtle.forward(180)

turtle.left(110)
turtle.forward(220)
turtle.right(140)
turtle.forward(220)
turtle.penup()
turtle.right(180)
turtle.forward(110)
turtle.left(70)
turtle.pendown()
turtle.forward(80)



turtle.exitonclick()
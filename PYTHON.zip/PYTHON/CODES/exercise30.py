#exercise30.py
#answerquiz7

import random

def roll_6_die():
    #numbers = [1,2,3,4,5,6]
    numbers = range(1, 7)
    return random.choice(numbers)
    
def roll_12_die():
    print("rolling 12 sided die")
    
    return random.randint(1,12)

def choose_die():    
    die_choice = input("""choose one:

1. 6 sided die
2. 12 sided die

>""")
    if die_choice == "1":
        result = roll_6_die()
    elif die_choice == "2":
        result = roll_12_die()
    else:
        result = None
    return result

result = choose_die()
 
if result is None:
    print("Type 1 or 2")
else:
    #print("checking result {}, format(result))

def check_winner(result):    
    user_choice = int(input("Guess a number: "))
    
    if result % user_choice == 0:
        print("You win")
    else:
        print("You lose")
def main(): 
    result= choose_die()
    if result is None:
        print("Type 1 or 2")
 else:
    #print("checking result {}".format(result))
    check_winner(result)

if__name__=="__main__":
    main()
    
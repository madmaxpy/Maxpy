#exercise44.py
import requests
import webbrowser

url = "https://random.dog/woof.json"
r = requests.get(url)
data = r.json()

webbrowser.open(data["url"])
# quiz5.py
# Make a POS program
# Show the user the menu. Use unpacking, zip, enumerate, or range
# Ask the user what they want to order
# print a receipt

names = [
        "Hotdog",
        "Adobong Manok",
        "Spaghetti",
 ]

prices = [
    30,
    60,
    25,
]
template ="{}: {} {}"
for i in range(len(names)):
    print(template.format(i + 1, names [i], prices [i]))

choice = input("What do you want? ")
choice = int(choice) - 1

template ="{}..........{}"
print("====")
print (" Unionbank restaurant ")

print (template.format(names[choice], prices[choice ]))

#for i item in enumerate(zip(names, prices)):
# name, price = item

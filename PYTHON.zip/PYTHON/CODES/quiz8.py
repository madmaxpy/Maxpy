# quiz8.py
#make POS program
# ask the user what they want to order
# If their order is not valid, ask them againg
# allow the user to input multiple orders
#print receipt

names = [
        "Hotdog",
        "Adobong Manok",
        "Spaghetti",
 ]

prices = [
    30,
    60,
    25,
]


template ="{}: {} {}"
for i in range(len(names)):
    print(template.format(i + 1, names [i], prices [i]))

cart = []


while True:
    print (" Unionbank restaurant ")
    choice = input("Do you still want to order y/n?")
    try:
        
        if choice.lower() in ["n", "no", "hinde", "ayaw na"]:
            break
        elif int(choice) in [1,2,3]:
            cart.append(choice)
            continue
            print("Again")
      
      
        else:
            print ("Select 1, 2, 3 Only")
            print("Again")
        
    except ValueError:
        print("Invalid selection")
template = "{: <20}{:.2f}"
print("====")
print(" Unionbank Restaurant ")
print(" ")

for choices in cart:
    print (template.format(names[int(choices)-1], prices[int(choices)-1]))
# exercise8.py
# data type:list
# for <iterator> in <container>:

heroes = ["Superman", "Batman", "Rizal", "Kardo", "Darna"]

for hero in heroes:
    print("I like " + hero)
# quiz1.py
# remove all the vowels from the sentence.
# print the sentence

sentence = "The quick brown fox jumps over the lazy dog"
sentence = sentence.replace("a", "")
sentence = sentence.replace("e", "")
sentence = sentence.replace("i", "")
sentence = sentence.replace("o", "")
sentence = sentence.replace("u", "")

sentence + sentence.replace("a", "").replace("e", "").replace("i", "").replace("o", "").replace("u", "")

print(sentence)
# exercise39.py
from pprint import pprint
import os


user = os.environ.get("USER")
password = os.environ.get ("PASSWORD")

path = os.environ["PATH"]
path = path.split(";")

pprint(path)
# exercise11.py
# zip() function

names = ["Hotdog", "Adobong Manok", "Spaghetti",]
prices = [30, 60, 25,]

menu = zip(names, prices)
menu = list(menu)
print (menu)

print ("====")
for item in zip(names, prices):
    print(item)
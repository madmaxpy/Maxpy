# exercise10.py

heroes = ["Superman", #0
          "Batman",  #1
          "Rizal",  #2
          "Kardo",  #3
          "Darna"] #4
          
heroes2 = heroes[:]
heroes3 = list(heroes)
heroes4 = heroes

heroes.append("Wonder Woman")
heroes2.append("Flash")
heroes3.append("Arrow")

print (heroes)
print (heroes2)
print (heroes3)
print (heroes4)

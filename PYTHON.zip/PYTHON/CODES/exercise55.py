#exercise55.py

from flask import Flask, url_for

app = Flask(__name__)

@app.route("/")
def show_cat():
    html = """<img src="{}" />"""
    html = html.format(url_for("static", filename="cat.jpeg"))
    return html

if __name__ == "__main__":
    app.run(debug=True) #, port=80, host="0.0.0.0")
print("What is your name?")
name = input()
print("You are " + name)

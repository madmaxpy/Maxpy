#exercise34.py
# data type: set

dc = ["Flash", "Superman", "Batman", "Wonder Woman", "Batman"]
marvel =["Iron man", "Hulk", "Flash", "Ant-man", "Ant-man"]

dc = set(dc)
marvel = set(marvel)

print(dc)
print(marvel)

print("===")

print(dc.union(marvel))
print(dc.intersection(marvel))
print(dc.difference(marvel))
print(marvel.difference(dc))
print(dc.symmetric_difference(marvel))

print("===")

print(dc | marvel)
print(dc & marvel)
print(dc - marvel)
print(marvel - dc)
print(dc ^ marvel)

print("===")
heroes = dc | marvel
for hero in heroes:
    print(hero)

print(len(heroes))
print(list(heroes))

print("Batman" in heroes)
print("Thanos" not in heroes)
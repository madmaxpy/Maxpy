# quiz2.py
# given these numbers, append the even numbers to a new list
# use for loops

numbers = [1,2,3,4,5,6]
evens = []

for number in numbers:
    is_even = (number %2 == 0)
    is_even = number % 2 == 0
    
    if is_even:
        evens.append(number)
or

for number in numbers:
    if number % 2 == 0 :
        evens.append(number)

print(evens)
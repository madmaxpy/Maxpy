#exercise54.py

from flask import Flask, url_for

app = Flask(__name__)

@app.route("/user/<username>")
def get_user(username):
    return("User {}".format(username))
    
@app.route("/id/<int:id>")
def get_id(id):
    return "Id #{}".format(id)

@app.route("/info")
@app.route("/info/")
@app.route("/info/<username>")
def get_info(username=None):
    if username is None:
        return "No username given"
        
    return username
if __name__ == "__main__":
    app.run(debug=True) #, port=80, host="0.0.0.0"
# exercise11.py
# unpacking

menu =[
    ["Hotdog",30],
    ["Adobong Manok",60],
    ["Sppaghetti", 25]
]

template = "{} costs {}"
#for item in menu:
    #name = item[0]
    #price = item[1]
    
    #name, price = item
    #print(template.format(name, price))
    
for name, price in menu:
    print(template.format(name, price))
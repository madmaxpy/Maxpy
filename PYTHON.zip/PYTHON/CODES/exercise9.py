# exercise9.py
# list slicing
# list [start:end (exclusive):step]

heroes = ["Superman", #0
          "Batman",  #1
          "Rizal",  #2
          "Kardo",  #3
          "Darna"] #4
print(heroes[0:3])
print(heroes[3:5])
print(heroes[0:5:2])
print(heroes[2:len(heroes)])
print(heroes[2:])

print(heroes[:3]) #top three
print(heroes[::-1])
print(heroes[:-2])
print(heroes[-3:]) #bottom three

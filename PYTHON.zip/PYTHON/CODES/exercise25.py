#exercise25.py
#import random

heroes =["Iron man",
		"Pacman",
		"Mayweather",
		"Rizal",
		"Saitama",
		]

best = random.choice(heroes)
power = random.randint(9000, 10000)

template = "The best hero is {}. Their power is {}"
output = template.format(best, power)
print(output)
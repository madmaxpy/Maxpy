#exercise41.py
import logging

logger = logging.getLogger(__name__)

handler_1 = logging.StreamHandler()
handler_2 = logging.FileHandler("exercise41.log")

handler_1 = setLevel(logging.INFO)
handler_2 = setLevel(logging.CRITICAL)

logger.addHandler(handler_1)
logger.addHandler(handler_2)


logger.error("There is an error")
logger.debug("This test is for debugging")
logger.warning("Something went wrong")
logger.critical("Something bad happened")
logger.info("The program is done")
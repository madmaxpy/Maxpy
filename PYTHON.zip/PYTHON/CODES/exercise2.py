# exerrcise2.py
print ("How old are you? ")

age = input()
age = int(age) + 10

print("In ten years, you will be " + str(age) + " years old")

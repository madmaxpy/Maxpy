# exercise5.py

#print("How old are you? ")

# > greater than
# >= greater than or equal
# < less than
# <= less than or equal
# == equal tobytes
# != not equal tobytes
# sytax:
# if <condition>:

age = input("How old are you? ")
age = int(age)


if age < 0 or age > 120:
    print("Not a valid age")
elif age >= 18:
    print("You can drive")
else:
    print("Wait a few more years")
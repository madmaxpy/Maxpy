# exercise50.py
import sqlite3

conn = sqlite3.connect(":memory:")
conn.row_factory = sqlite3.Row
curr = conn.cursor()

curr.execute("""CREATE TABLE record (name TEXT, motto TEXT)""")


sql = """INSERT INTO RECORD VALUES (?, ?)"""
curr.execute(sql, ("Alyssa", "world peace"))

data = [
    ("Arnold", "I'll beback"),
    ("Jon Snow", "You know nothing"),
    ("John cena", "You can't see me"),
]

curr.executemany(sql, data)

conn.commit()


for row in curr.execute("SELECT * FROM RECORD"):
    print(row["name"], row["MOTTO"])
    
conn.close()
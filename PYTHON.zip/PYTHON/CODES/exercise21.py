#exercise21.py
# file mode:
# w-write

#f = open("Hello.txt", "w")
#f.write("Hello world")
#f.close()

with open("Hello.txt", "w") as f:
    f.write("Hello world")
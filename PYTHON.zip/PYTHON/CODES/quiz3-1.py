# quiz3.py
# given these string, append the upper case string
# use for loops

heroes = ["Superman", "Batman", "Rizal", "Kardo", "Darna"]
heroes_upper = []

heroes_upper = [hero.upper() for hero in heroes]
heroes_upper = [hero.upper()
				for hero in heroes]
print(heroes_upper)
#exercise40.py
import logging

logging.basicConfig(level=logging.DEBUG,
                    filename="exercise40.log",
                    filemode="w",
                    format="%(asctime)s - %(name)s - %(levelname)s:")


logging.error("There is an error")
logging.debug("This test is for debugging")
logging.warning("Something went wrong")
logging.critical("Something bad happened")
logging.info("The program is done")
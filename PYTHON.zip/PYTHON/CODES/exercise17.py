#exercise17.py
#align & float

names = ["Hotdog", "Adobong Manok", "Spaghetti",]
prices = [30, 60, 25,]

template = "{: <20}{:.2f}"

for name, price in zip(names, prices):
    print(template.format(name, price))
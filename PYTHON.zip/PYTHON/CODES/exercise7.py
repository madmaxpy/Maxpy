# exercise7.py
# data type:list

heroes = ["Superman", "Batman", "Rizal", "Kardo", "Darna"]

heroes.append("Lastikman")
heroes.remove("Kardo")

print("Batman" in heroes)
print ("Joker" not in heroes)

heroes[0] = "Clark"
del heroes [1]  

print(heroes)
# exercise49.py
import sqlite3

conn = sqlite3.connect(":memory:")
curr = conn.cursor()

curr.execute("""CREATE TABLE record (name TEXT, motto TEXT)""")
curr.execute("""INSERT INTO RECORD VALUES("Alyssa", "World Peace")""")

sql = """INSERT INTO RECORD VALUES (?, ?)"""
curr.execute(sql, ("Alyssa", "world peace"))

data = [
    ("Arnold", "I'll beback"),
    ("Jon Snow", "You know nothing"),
    ("John cena", "You can't see me"),
]

curr.executemany(sql, data)

conn.commit()


for row in curr.execute("SELECT * FROM RECORD"):
    print(row)

print("===")
curr.execute("SELECT MOTTO FROM RECORD")
for row in curr.fetchall():
    print(row)
    
conn.close()
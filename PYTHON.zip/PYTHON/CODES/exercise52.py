#exercise52.py
from flask import Flask

app = Flask(__name__)

@app.route("/")
def index():
    1/0
    return """
<b>Hello World</b>"

Good afternoon
""".replace("\n", "br/>")

@app.route("/info")
@app.route("/bio")
@app.route("/data/secret")
def get_info():
    template = """<b>Name</b>: {}
<b>Motto</b.:{}
"""
    output = template.format("Alyssa", "Alright")
    return output.replace("\n", "<br />")

if __name__== "__main__":
    app.run(debug=True) #port=80 host="0.0.0.0")   
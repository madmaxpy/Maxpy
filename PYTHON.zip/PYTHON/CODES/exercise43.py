#exercisse43.py
from datetime import datetime

d = datetime.now()
d = datetime(2000, 1, 1)
print(d)
print(d.strftime("%b %m %Y, %H:%M:%S %p"))
#exercise20.py
#data type: tuple


best = ("Batman")
print(best)
print(type(best))

heroes = ("Superman", "Batman", "Wonder Woman")


print(heroes)
print(type(heroes))

print(heroes[1])

for hero in heroes:
    print(hero)
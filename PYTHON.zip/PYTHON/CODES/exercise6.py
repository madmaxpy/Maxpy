# exercise6.py
# data type:list

heroes = ["Superman", "Batman", "Rizal", "Kardo", "Darna"]

print(heroes)
print(type(heroes))
print(heroes[1])
print(len(heroes))

#print (heroes[5])
#print (heroes[len(heroes)-1]

#print(heroes[-1])
print(heroes[-6])
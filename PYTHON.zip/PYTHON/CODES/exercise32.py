# exercise32.py
# data type: dictionary (key-value storage)

record ={
    "name": "Paolo",
    "age": 21,
    "favorite fruits": ["Banana", "Apple"],
}

print(record)
print(record["name"])

del record["favorite fruits"]
record["sexiness"] = True
print(record["sexiness"])

print("===")
for key in record:
    print(key)
    
print("===")
for value in  record.values():
    print(value)

print("===")
for key, value in record.items():
    print(key,value)
  
print("===")
print("name" in record)
print("nickname" not in record)

print("===")
print(record.get("name"))
print(record.get("nickname"))
print(record.get("nickname", "kulit mo wala talaga"))

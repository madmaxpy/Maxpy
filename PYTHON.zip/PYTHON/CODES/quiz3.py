# quiz3.py
# given these string, append the upper case string
# use for loops

heroes = ["Superman", "Batman", "Rizal", "Kardo", "Darna"]
heroes_upper = []

for hero in heroes:
    heroes_upper.append(hero.upper())
print(heroes_upper)
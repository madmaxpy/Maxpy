#exercise19.py
# split
#str.split(separator) -> list
# eparator.join (container) -> string

sentence = "The quick brown fox"
words = sentence.split(" ")
print(words)
print(type(words))

sentence2 = " ".join(words)
print(sentence2)
print(type(sentence2))
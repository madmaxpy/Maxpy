#exercise22.py

f = open("Hello.txt", "a")
f.write("spam" * 100)
f.write("\n")
f.close()

with open("Hello.txt", "a") as f:
    f.write("spam" * 100)
    f.write("\n")